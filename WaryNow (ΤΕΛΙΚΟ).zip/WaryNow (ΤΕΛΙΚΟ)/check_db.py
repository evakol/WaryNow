import sqlite3

try:
    conn = sqlite3.connect("warynow.db")
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM conflicts WHERE status = 'active'")
    count = cursor.fetchone()[0]
    print(f"✅ Βρέθηκαν {count} ενεργές συγκρούσεις στη βάση!")
    conn.close()
except Exception as e:
    print(f"❌ Σφάλμα στη βάση: {e}")