import sqlite3

DATABASE_PATH = "warynow.db"

def populate_presentation_data():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    print("⏳ Καθαρισμός και γέμισμα βάσης δεδομένων για την παρουσίαση...")

    # Έλεγχος: Καθαρισμός παλιών δεδομένων
    cursor.execute("DELETE FROM conflicts")
    cursor.execute("DELETE FROM raw_reports")
    
    # Προσπάθεια καθαρισμού του πίνακα υποδομών (με try-except για ασφάλεια)
    try:
        cursor.execute("DELETE FROM infrastructures")
    except sqlite3.OperationalError:
        pass 

    # --- 1. Δεδομένα για τον Χάρτη (UC4/UC5) & Στατιστικά (UC11) ---
    conflicts_data = [
        ("Ukraine: Ένοπλη Σύρραξη στο Κίεβο", "Ανταλλαγή πυρών.", 50.45, 30.52, "Ukraine", "high", "active", "2026-05-10 10:00:00"),
        ("Syria: Συνοριακή Ένταση", "Συγκρούσεις στα βόρεια σύνορα.", 36.2, 37.1, "Syria", "medium", "active", "2026-05-15 12:00:00"),
        ("Taiwan: Ναυτικό Επεισόδιο", "Στρατιωτικά πλοία στα στενά.", 23.5, 121.0, "Taiwan", "medium", "active", "2026-05-20 14:00:00"),
        ("Sudan: Εμφύλιες Ταραχές", "Οδομαχίες στο Χαρτούμ.", 15.5, 32.5, "Sudan", "high", "active", "2026-05-25 16:00:00")
    ]

    cursor.executemany("""
        INSERT INTO conflicts (title, description, latitude, longitude, country, intensity, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, conflicts_data)

    # --- 2. & 3. Δεδομένα για Moderation (UC10) & Ροή Ειδήσεων (UC6) ---
    reports_data = [
        ("Ύποπτη κίνηση στρατευμάτων", "Αναφορά από τοπικά μέσα.", 10.0, 10.0, "Local News", "flagged", "2026-05-28 09:00:00"),
        ("Έκρηξη σε αποθήκη πυρομαχικών", "Ανεπιβεβαίωτες πληροφορίες.", 20.0, 20.0, "Twitter", "flagged", "2026-05-29 11:00:00"),
        ("Ειρηνική διαδήλωση στην πλατεία", "Δεν υπάρχει βία.", 30.0, 30.0, "News", "flagged", "2026-05-30 10:00:00"),
        ("ΟΗΕ: Νέα έκκληση για εκεχειρία στη Μέση Ανατολή.", "", None, None, "Reuters", "processed", "2026-05-30 12:00:00"),
        ("Αυξημένη στρατιωτική κινητικότητα εντοπίστηκε από δορυφόρους.", "", None, None, "CNN", "processed", "2026-05-30 13:00:00")
    ]

    cursor.executemany("""
        INSERT INTO raw_reports (title, description, latitude, longitude, source, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, reports_data)

    # --- 4. Δεδομένα για τις Υποδομές (UC9) ---
    infra_data = [
        ("Κεντρικό Νοσοκομείο Κιέβου", "Hospital", 50.42, 30.50),
        ("Κεντρικός Σταθμός Ενέργειας (Ουκρανία)", "Power Plant", 50.48, 30.55),
        ("Εγκατάσταση Υδροδότησης (Συρία)", "Water Supply", 36.1, 37.0),
        ("Σταθμός Τηλεπικοινωνιών (Ταϊβάν)", "Communications", 23.6, 121.1)
    ]

    try:
        cursor.executemany("""
            INSERT INTO infrastructures (name, category, latitude, longitude)
            VALUES (?, ?, ?, ?)
        """, infra_data)
        print("✅ Προστέθηκαν τα δεδομένα Κρίσιμων Υποδομών (UC9)!")
    except sqlite3.OperationalError as e:
        print(f"⚠️ Προσοχή: Δεν μπήκαν οι υποδομές. Σφάλμα: {e}")

    conn.commit()
    conn.close()
    print("✅ Η βάση γέμισε επιτυχώς με το υλικό παρουσίασης! Μπορείτε να ξεκινήσετε την εφαρμογή.")

if __name__ == "__main__":
    populate_presentation_data()