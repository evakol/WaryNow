import customtkinter as ctk
from tkinter import messagebox
from app.services.uc11_service import get_statistics, export_statistics_file

def open_statistics_window():
    """Ανοίγει το παράθυρο στατιστικών από το Αριστερό Μενού με CustomTkinter."""
    # Χρήση CTkToplevel για να είναι συμβατό με την αρχική σου οθόνη
    window = ctk.CTkToplevel()
    window.title("WaryNow - UC11 Εξαγωγή Στατιστικών")
    window.geometry("450x380")
    window.configure(fg_color="#1a1a1a") # Σκούρο φόντο
    window.attributes("-topmost", True)  # Για να εμφανιστεί σίγουρα πάνω από τον χάρτη

    ctk.CTkLabel(window, text="Παρουσίαση Λειτουργιών", font=ctk.CTkFont(size=18, weight="bold"), text_color="white").pack(pady=(20, 5))
    ctk.CTkLabel(window, text="Στατιστικά Στοιχεία Συγκρούσεων", font=ctk.CTkFont(size=14), text_color="lightgray").pack(pady=5)

    # Προσομοίωση επιλογής ημερομηνιών
    ctk.CTkLabel(window, text="Εύρος: 2026-05-01 έως 2026-05-31", font=ctk.CTkFont(size=12, slant="italic"), text_color="#FBBF24").pack(pady=15)

    def process_stats():
        # Κλήση της back-end λογικής
        stats = get_statistics("2026-05-01", "2026-05-31")
        if stats:
            lbl_res.configure(text=f"Συνολικά Γεγονότα (Raw Reports & Conflicts): {stats['total']}\nΕνεργές Συγκρούσεις (Active): {stats['active']}")
            btn_export.configure(state="normal", fg_color="#10B981", hover_color="#059669")
            window.stats_data = stats
        else:
            lbl_res.configure(text="Δεν βρέθηκαν δεδομένα για αυτό το εύρος.")

    ctk.CTkButton(window, text="Υπολογισμός Έντασης", command=process_stats, font=ctk.CTkFont(weight="bold"), fg_color="#3B82F6", hover_color="#2563EB").pack(pady=10)

    lbl_res = ctk.CTkLabel(window, text="", font=ctk.CTkFont(size=14), text_color="white", justify="center")
    lbl_res.pack(pady=15)

    def current_export():
        if export_statistics_file(window.stats_data, "PDF"):
            messagebox.showinfo("Σύστημα", "Το αρχείο PDF αποθηκεύτηκε επιτυχώς στο Device Storage!")
            window.destroy()

    btn_export = ctk.CTkButton(window, text="💾 Εξαγωγή σε PDF (Device Storage)", command=current_export, state="disabled", fg_color="gray", font=ctk.CTkFont(weight="bold"))
    btn_export.pack(pady=10)