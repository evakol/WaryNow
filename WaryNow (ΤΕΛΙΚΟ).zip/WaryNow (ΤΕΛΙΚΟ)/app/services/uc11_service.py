import sqlite3
import csv
import os
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

DATABASE_PATH = os.path.join(os.path.dirname(
    os.path.dirname(os.path.dirname(__file__))), "warynow.db")

def get_statistics(start_date, end_date):
    """Υπολογισμός στατιστικών από τα conflicts της SQLite για το συγκεκριμένο χρονικό εύρος."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT status, created_at FROM conflicts")
        all_conflicts = cursor.fetchall()
        conn.close()
        
        filtered_conflicts = [c for c in all_conflicts if c[1] and (start_date <= c[1][:10] <= end_date)]
        
        total_events = len(filtered_conflicts)
        active_count = sum(1 for c in filtered_conflicts if c[0] == "active")
        
        return {
            "total": total_events,
            "active": active_count,
            "start_date": start_date,
            "end_date": end_date
        }
    except Exception as e:
        print(f"[Error] Σφάλμα στατιστικών: {e}")
        conn.close()
        return None

def export_statistics_file(stats_data, file_format="PDF"):
    """
    Πραγματική εξαγωγή και αποθήκευση του αρχείου στατιστικών στο φάκελο του project.
    Υποστηρίζει CSV και PDF (με πλήρη υποστήριξη Ελληνικών).
    """
    if not stats_data:
        return False
        
    # Δημιουργία καθαρού ονόματος αρχείου βάσει ημερομηνιών
    base_filename = f"WaryNow_Report_{stats_data['start_date']}_to_{stats_data['end_date']}"

    # - ΠΡΑΓΜΑΤΙΚΗ ΕΞΑΓΩΓΗ ΣΕ CSV -
    if file_format.upper() == "CSV":
        filename = base_filename + ".csv"
        try:
            with open(filename, mode='w', newline='', encoding='utf-8-sig') as file:
                writer = csv.writer(file)
                writer.writerow(["Κριτήριο Στατιστικών", "Τιμή / Καταμέτρηση"])
                writer.writerow(["Ημερομηνία Έναρξης", stats_data['start_date']])
                writer.writerow(["Ημερομηνία Λήξης", stats_data['end_date']])
                writer.writerow(["Συνολικά Γεγονότα στη Βάση", stats_data['total']])
                writer.writerow(["Ενεργές Σύρραξεις (Active)", stats_data['active']])
            print(f"[DeviceStorage] Το αρχείο CSV δημιουργήθηκε: {filename}")
            return True
        except Exception as e:
            print(f"[Error] Αποτυχία εξαγωγής CSV: {e}")
            return False

    # - ΠΡΑΓΜΑΤΙΚΗ ΕΞΑΓΩΓΗ ΣΕ PDF -
    elif file_format.upper() == "PDF":
        filename = base_filename + ".pdf"
        try:
            # Αρχικοποίηση του PDF Canvas
            c = canvas.Canvas(filename)
            
            # Φόρτωση της Arial από τα Windows για να υποστηρίζονται τα Ελληνικά
            windows_font_path = r"C:\Windows\Fonts\arial.ttf"
            if os.path.exists(windows_font_path):
                pdfmetrics.registerFont(TTFont('ArialGreek', windows_font_path))
                font_name = 'ArialGreek'
            else:
                font_name = 'Helvetica' # Fallback αν δεν βρεθεί

            # Σχεδίαση Κεφαλίδας
            c.setFont(font_name, 16)
            c.drawString(50, 780, "WaryNow - Κεντρικό Σύστημα Γεωειδοποιήσεων")
            c.setFont(font_name, 12)
            c.setFillColorRGB(0.3, 0.3, 0.3)
            c.drawString(50, 760, "Αναφορά Στατιστικών Στοιχείων Παγκόσμιων Συγκρούσεων")
            
            # Οριζόντια διαχωριστική γραμμή
            c.setStrokeColorRGB(0.7, 0.7, 0.7)
            c.line(50, 745, 550, 745)
            
            # Σώμα Αναφοράς (Δεδομένα)
            c.setFillColorRGB(0, 0, 0)
            c.setFont(font_name, 12)
            
            y_position = 700
            c.drawString(50, y_position, f"• Φιλτράρισμα από: {stats_data['start_date']}")
            c.drawString(50, y_position - 25, f"• Φιλτράρισμα έως: {stats_data['end_date']}")
            
            c.line(50, y_position - 45, 550, y_position - 45)
            
            # Ανάδειξη των Μετρικών
            c.setFont(font_name, 13)
            c.drawString(50, y_position - 80, f"Συνολικά Γεγονότα (Raw Reports): {stats_data['total']}")
            c.drawString(50, y_position - 110, f"Ενεργές Συγκρούσεις στο Χάρτη (Active): {stats_data['active']}")
            
            # Υποσέλιδο
            c.setFont(font_name, 9)
            c.setFillColorRGB(0.5, 0.5, 0.5)
            c.drawString(50, 50, "WaryNow Security Application • 2026 Academic Deliverable")
            
            # Αποθήκευση αρχείου
            c.save()
            print(f"[DeviceStorage] Το αρχείο PDF δημιουργήθηκε: {filename}")
            return True
        except Exception as e:
            print(f"[Error] Αποτυχία εξαγωγής PDF: {e}")
            return False

    return False