from datetime import datetime
import sqlite3
import os

DATABASE_PATH = os.path.join(os.path.dirname(
    os.path.dirname(os.path.dirname(__file__))), "warynow.db")

def get_flagged_reports():
    """Ανάκτηση των αναφορών με κατάσταση 'flagged' από την SQLite."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    # ΔΙΟΡΘΩΣΗ 1: Ο πίνακας είναι raw_reports
    cursor.execute("SELECT id, title, description, status FROM raw_reports WHERE status = 'flagged'")
    reports = cursor.fetchall()
    conn.close()
    return reports

def verify_report(report_id):
    """Έγκριση αναφοράς: status='verified' και δημιουργία Conflict με status='active'."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # ΔΙΟΡΘΩΣΗ 2: Τραβάμε και το latitude / longitude για να μην κρασάρει ο χάρτης!
    cursor.execute("SELECT title, description, latitude, longitude FROM raw_reports WHERE id = ?", (report_id,))
    report = cursor.fetchone()
    
    if report:
        title, description, lat, lng = report
        
        # Αλλαγή σε μικρά γράμματα 'verified' 
        cursor.execute("UPDATE raw_reports SET status = 'verified' WHERE id = ?", (report_id,))
        
        # Δημιουργία της σύγκρουσης (Conflict) με τα νέα πεδία της βάσης
        current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Αν η είδηση δεν έχει συντεταγμένες, βάζουμε προσωρινές (π.χ. στον Ισημερινό) για να μη σπάσει το πρόγραμμα
        safe_lat = lat if lat is not None else 0.0
        safe_lng = lng if lng is not None else 0.0
        
        # ΔΙΟΡΘΩΣΗ 3: Εισαγωγή στον πίνακα conflicts με country (Unknown) και intensity (Medium) ως defaults
        cursor.execute("""
            INSERT INTO conflicts (title, description, latitude, longitude, country, intensity, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, 'active', ?)
        """, (title, description, safe_lat, safe_lng, "Unknown", "Medium", current_date))
        
        conn.commit()
        conn.close()
        return True
        
    conn.close()
    return False

def reject_report(report_id):
    """Απόρριψη αναφοράς: status='rejected'."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    # ΔΙΟΡΘΩΣΗ 4: Ο πίνακας είναι raw_reports
    cursor.execute("UPDATE raw_reports SET status = 'rejected' WHERE id = ?", (report_id,))
    conn.commit()
    conn.close()
    return True