# config.py
# Ενοποιημένο αρχείο ρυθμίσεων

# - Βάση Δεδομένων -
DATABASE_URL = "warynow.db"
DATABASE_FILE = "warynow.db"

# - Geo Thresholds -
MERGE_THRESHOLD_KM = 50      # Κάτω από 50km -> merge
BORDERLINE_THRESHOLD_KM = 100  # 50-100km -> pending

# - Keywords για φιλτράρισμα ειδήσεων -
CONFLICT_KEYWORDS = [
    "war", "attack", "conflict", "explosion",
    "military", "strike", "battle", "shooting"
]
SCHEDULER_INTERVAL_MINUTES = 30
GDELT_API_URL = "https://api.gdeltproject.org/api/v2/doc/doc"

# - Geo-Alerts & Infrastructure -
MAX_ALERT_RADIUS_KM = 500             # Μέγιστη ακτίνα για γεω-ειδοποιήσεις
INFRASTRUCTURE_SEARCH_RADIUS_KM = 50  # Αρχική ακτίνα αναζήτησης υποδομών
RADIUS_EXPAND_FACTOR = 1.5            # Παράγοντας αύξησης ακτίνας